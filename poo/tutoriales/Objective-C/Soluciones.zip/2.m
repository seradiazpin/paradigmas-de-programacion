# import <Foundation/Foundation.h>
# import <stdio.h>

inline int randomIntBetween(int a, int b){ //inclusive
	return rand()%(b-a+1) + a;
}

@interface Password:NSObject{
	int length;
	NSString * password;
}

-(id)init;

-(id)init:(int)_length;
-(bool)isStrong;
-(NSString *)generatePassword;

@property(copy,readonly)NSString * password;
@property(readwrite)int length;

@end

@implementation Password
	
@synthesize password;
@synthesize length;

-(NSString *)generatePassword{
	char aux[length];
	int i;
	for(i=0 ; i<length ; i++){
		aux[i] = randomIntBetween('0','z');
	}
	NSString *str = [NSString stringWithFormat:@"%s", aux];
	password = str;
	return str;
}

-(id)init{
	length = 0;
	return self;
}

-(id)init:(int)_length{
	length = _length;
	[self generatePassword];
	return self;
}

-(bool)isStrong{
	int upper=0,lower=0,nums=0,i;

	for(i=0 ; i<[password length]; i++){
		int ascii = [password characterAtIndex: i];
		if(ascii>='a' && ascii<='z') lower++;
		else if(ascii>='A' && ascii<='Z') upper++;
		else if(ascii>='0' && ascii<='9') nums++;
	}

	return upper>2 && lower>1 && nums>5;
}

@end

inline void initRandomGenerator(){
	srand(time(NULL));
}

int main(){
	initRandomGenerator();
	NSAutoreleasePool *myPool = [[NSAutoreleasePool alloc] init];

	NSMutableArray * arr = [NSMutableArray new];
	NSMutableArray * booleans = [NSMutableArray new];

	NSLog(@"Ingrese el numero de passwords");
	int numberOfPasswords,length;
	scanf("%d",&numberOfPasswords);
	int i;

	for(i=0 ; i<numberOfPasswords ; i++){
		NSLog(@"Ingrese la longitud");
		scanf("%d",&length);
		Password * pass = [[Password alloc] init: length];

		[arr addObject: pass];
		bool aux = [ [arr objectAtIndex: i] isStrong];
		[booleans addObject: [NSNumber numberWithBool: aux]];
	}

	for(i=0 ; i<numberOfPasswords ; i++){
		NSString * aux = @"verdadero";
		if( [booleans objectAtIndex: i] == [NSNumber numberWithBool: 0] ) aux = @"falso";
		NSLog(@"%@ %@",[ [arr objectAtIndex: i] password ] ,aux);
	}

	[myPool drain];
	return 0;
}
















