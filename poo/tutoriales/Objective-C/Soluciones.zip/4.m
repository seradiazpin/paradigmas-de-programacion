# import <Foundation/Foundation.h>

@protocol Deliverable
-(void)deliver;
-(void)borrow;
-(NSNumber *)isBorrowed;
@end

@interface Serie:NSObject <Deliverable>{
	NSString * title;
	int numberOfSeasons;
	NSNumber * borrowed;
	NSString * type;
	NSString * author;
}

-(id)init;
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author;
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author numberOfSeasons:(int)_numberOfSeasons type:(NSString *)_type;
-(NSString *)toString;

@property(copy,readwrite) NSString * title;
@property(copy,readwrite) NSString * author;
@property(copy,readwrite) NSString * type;
@property(readwrite) int numberOfSeasons;
@property(nonatomic,retain) NSNumber * borrowed;

@end

@implementation Serie
	
@synthesize title;
@synthesize author;
@synthesize type;
@synthesize numberOfSeasons;
@synthesize borrowed;

-(id)init{
	numberOfSeasons = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = @"";
	author = @"";
	type = @"";
	return self;
}
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author{
	numberOfSeasons = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = _title;
	author = _author;
	type = @"";
	return self;
}
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author numberOfSeasons:(int)_numberOfSeasons type:(NSString *)_type{
	numberOfSeasons = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = _title;
	author = _author;
	type = _type;
	return self;
}

-(NSString *)toString{
	return [NSString stringWithFormat: @"Title %@, numberOfSeasons %d, borrowed %d, author %@, type %@",title,numberOfSeasons,borrowed,author,type ];
}

-(void)deliver{
	borrowed = [NSNumber numberWithBool:NO];
}
-(void)borrow{
	borrowed = [NSNumber numberWithBool:YES];
}
-(NSNumber *)isBorrowed{
	return borrowed;
}

@end

@interface VideoGame:NSObject <Deliverable>{
	NSString * title;
	int hours;
	NSNumber * borrowed;
	NSString * type;
	NSString * author;
}

-(id)init;
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author;
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author hours:(int)_hours type:(NSString *)_type;
-(NSString *)toString;

@property(copy,readwrite) NSString * title;
@property(copy,readwrite) NSString * author;
@property(copy,readwrite) NSString * type;
@property(readwrite) int hours;
@property(nonatomic,retain) NSNumber * borrowed;

@end


@implementation VideoGame
	
@synthesize title;
@synthesize author;
@synthesize type;
@synthesize hours;
@synthesize borrowed;

-(id)init{
	hours = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = @"";
	author = @"";
	type = @"";
	return self;
}
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author{
	hours = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = _title;
	author = _author;
	type = @"";
	return self;
}
-(id)initWithTitle:(NSString *)_title author:(NSString *)_author hours:(int)_hours type:(NSString *)_type{
	hours = 3;
	borrowed = [NSNumber numberWithBool:NO];
	title = _title;
	author = _author;
	type = _type;
	return self;
}

-(NSString *)toString{
	return [NSString stringWithFormat: @"Title %@, hours %d, borrowed %d, author %@, type %@",title,hours,borrowed,author,type ];
}

-(void)deliver{
	borrowed = [NSNumber numberWithBool:NO];
}
-(void)borrow{
	borrowed = [NSNumber numberWithBool:YES];
}
-(NSNumber *)isBorrowed{
	return borrowed;
}

@end

int main(int argc, char const *argv[])
{
	NSAutoreleasePool *myPool = [[NSAutoreleasePool alloc] init];
	NSMutableArray * videoGames = [NSMutableArray new];
	NSMutableArray * series = [NSMutableArray new];

	[ series addObject: [[Serie alloc] init]  ];
	[ series addObject: [ [Serie alloc] initWithTitle:@"Expedientes x" author:@"Jose guayamaral" numberOfSeasons:9 type:@"ficion"] ];  
	[ series addObject: [ [Serie alloc] initWithTitle:@"Expedientes y" author:@"Maria guayamaral" numberOfSeasons:9 type:@"novela"] ];
	[ series addObject: [ [Serie alloc] initWithTitle:@"Expedientes z" author:@"Jose juanto" numberOfSeasons:9 type:@"accion"] ];
	[ series addObject: [ [Serie alloc] initWithTitle:@"Expedientes aa" author:@"Mauricio rondon" numberOfSeasons:9 type:@"comic"] ];

	[videoGames addObject:  [ [VideoGame alloc] init ] ];
	[videoGames addObject:  [ [VideoGame alloc] initWithTitle:@"Fifa 34" author:@"Pedro" hours:9 type:@"Deportes"] ];
	[videoGames addObject:  [ [VideoGame alloc] initWithTitle:@"PES 34" author:@"Pedro" hours:9 type:@"Deportes"] ];
	[videoGames addObject:  [ [VideoGame alloc] initWithTitle:@"GTA bogota" author:@"Pedro" hours:9 type:@"Realista"] ];
	[videoGames addObject:  [ [VideoGame alloc] initWithTitle:@"Halo 12" author:@"Pedro" hours:9 type:@"Accion"] ];

	[ [videoGames objectAtIndex: 0] borrow];
	[ [videoGames objectAtIndex: 2] borrow];
	[ [videoGames objectAtIndex: 4] borrow];

	[ [series objectAtIndex: 1] borrow];
	[ [series objectAtIndex: 3] borrow];

	int numberOfBorrowed = 0,i;
	for( i=0 ; i<5 ; i++){
		if( [ [series objectAtIndex: i] isBorrowed] == [NSNumber numberWithBool:YES] ){
			numberOfBorrowed++;
			[ [series objectAtIndex: i] deliver];
		}
	}

	for(i=0 ; i<5 ; i++){
		if( [ [videoGames objectAtIndex: i] isBorrowed] == [NSNumber numberWithBool:YES] ){
			numberOfBorrowed++;
			[ [videoGames objectAtIndex: i] deliver];
		}
	}

	NSLog(@"Numero de prestados %d",numberOfBorrowed);

	[myPool drain];
	return 0;
}