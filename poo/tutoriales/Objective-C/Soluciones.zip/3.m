//
//  main.m
//  Main
//
//  Created by Manuel Alejandro Vergara Diaz on 1/05/16.
//  Copyright (c) 2016 Manuel Alejandro Vergara Diaz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Electrodomestico: NSObject {
    NSNumber *precioBase;
    NSString *color;
    NSNumber *consumoEnergetico;
    NSNumber *peso;
}
-( id ) inicializar;
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial;
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial Color: ( NSString* ) colorInicial Consumo: ( NSNumber* ) consumoInicial yPeso: ( NSNumber* ) pesoInicial;
-( int ) precioFinal;
-( void ) imprimir;
@end

@implementation Electrodomestico
-( id ) inicializar {
    precioBase = [ NSNumber numberWithInt: 100 ];
    color = @"blanco";
    consumoEnergetico = [ NSNumber numberWithChar: 'F' ];
    peso = [ NSNumber numberWithInt: 5 ];
    return self;
}
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial {
    precioBase = precioInicial;
    color = @"blanco";
    consumoEnergetico = [ NSNumber numberWithChar: 'F' ];
    peso = pesoInicial;
    return self;
}
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial Color: ( NSString* ) colorInicial Consumo: ( NSNumber* ) consumoInicial yPeso: ( NSNumber* ) pesoInicial {
    precioBase = precioInicial;
    color = [ Electrodomestico comprobarColor: colorInicial ];
    consumoEnergetico = [ Electrodomestico comprobarConsumoEnergetico: consumoInicial ];
    peso = pesoInicial;
    return self;
}
+( NSString* ) comprobarColor: ( NSString* ) colorInicial {
    NSString *colorInLowerCase = [ colorInicial lowercaseString ];
    if( [ colorInLowerCase isEqualToString: @"blanco" ] ||
        [ colorInLowerCase isEqualToString: @"negro" ] ||
        [ colorInLowerCase isEqualToString: @"rojo" ] ||
        [ colorInLowerCase isEqualToString: @"azul" ] ||
        [ colorInLowerCase isEqualToString: @"gris" ] )
        return colorInicial;
    return @"blanco";
}
+( NSNumber* ) comprobarConsumoEnergetico: ( NSNumber* ) consumoInicial {
    if( [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'A' ] ] ||
       [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'B' ] ] ||
       [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'C' ] ] ||
       [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'D' ] ] ||
       [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'E' ] ] ||
       [ consumoInicial isEqualToNumber: [ NSNumber numberWithChar: 'F' ] ] )
        return consumoInicial;
    return [ NSNumber numberWithChar: 'F' ];
}
-( int ) precioFinal {
    int respuesta = 0;
    if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'A' ] ] )
        respuesta += 100;
    else if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'B' ] ] )
        respuesta += 80;
    else if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'C' ] ] )
        respuesta += 60;
    else if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'D' ] ] )
        respuesta += 50;
    else if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'E' ] ] )
        respuesta += 30;
    else if( [ consumoEnergetico isEqualToNumber: [ NSNumber numberWithChar: 'F' ] ] )
        respuesta += 10;
    int tmp = [ peso intValue ];
    if( tmp < 20 )
        respuesta += 10;
    else if( tmp < 50 )
        respuesta += 50;
    else if( tmp < 80 )
        respuesta += 80;
    else
        respuesta += 100;
    return respuesta;
}
-( void ) imprimir {
    NSLog( @"Precio base: %@\n", precioBase );
    NSLog( @"Color: %@\n", color );
    NSLog( @"Consumo energetico: %@\n", consumoEnergetico );
    NSLog( @"Peso: %@\n", peso );
}
@end

@interface Lavadora: Electrodomestico {
    NSNumber *carga;
}
-( id ) inicializar;
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial;
-( id ) inicializarConCarga: (  NSNumber* ) cargaInicial;
@end

@implementation Lavadora
-( id ) inicializar {
    [ super inicializar ];
    carga = [ NSNumber numberWithInt: 5 ];
    return self;
}
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial {
    [ super inicializarConPrecio: precioInicial yPeso: pesoInicial ];
    carga = [ NSNumber numberWithInt: 5 ];
    return self;
}
-( id ) inicializarConCarga: (  NSNumber* ) cargaInicial {
    [ super inicializar ];
    carga = cargaInicial;
    return self;
}
-( int ) precioFinal {
    if( [ carga intValue ] <= 30 )
        return [ super precioFinal ];
    return [ super precioFinal ]+50;
}
-( int ) obtenerCarga {
    return [ carga intValue ];
}
-( void ) imprimir {
    [ super imprimir ];
    NSLog( @"Carga de la lavadora: %@\n", carga );
}
@end

@interface Televisor: Electrodomestico {
    NSNumber *resolucion;
    NSNumber *sintonizadorTDT;
}
-( id ) inicializar;
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial;
-( id ) inicializarConResolucion: (  NSNumber* ) resolucionInicial ySintonizador: ( NSNumber* ) sintonizadorInicial;
@end

@implementation Televisor
-( id ) inicializar {
    [ super inicializar ];
    resolucion = [ NSNumber numberWithInt: 20 ];
    sintonizadorTDT = [ NSNumber numberWithBool: false ];
    return self;
}
-( id ) inicializarConPrecio: (  NSNumber* ) precioInicial yPeso: ( NSNumber* ) pesoInicial {
    [ super inicializarConPrecio: precioInicial yPeso: pesoInicial ];
    resolucion = [ NSNumber numberWithInt: 20 ];
    sintonizadorTDT = [ NSNumber numberWithBool: false ];
    return self;
}
-( id ) inicializarConResolucion: ( NSNumber* ) resolucionInicial ySintonizador: ( NSNumber* ) sintonizadorInicial {
    [ super inicializar ];
    resolucion = resolucionInicial;
    sintonizadorTDT = sintonizadorInicial;
    return self;
}
-( int ) precioFinal {
    int resultado = [ super precioFinal ];
    if( [ sintonizadorTDT intValue ] != 0 )
        resultado += 50;
    if( [ resolucion intValue ] >= 40 )
        resultado = resultado+resultado*0.3;
    return resultado;
}
-( int ) obtenerResolucion {
    return [ resolucion intValue ];
}
-( bool ) obtenerSintonizadorTDT {
    return [ sintonizadorTDT intValue ];
}
-( void ) imprimir {
    [ super imprimir ];
    NSLog( @"Resolucion del televisor: %@\n", resolucion );
    NSLog( @"Sintonizador TDT: %@\n", sintonizadorTDT );
}
@end

NSString * readString( ) {
    char aux[ 100 ];
    scanf( "%s", aux );
    NSString *str = [ NSString stringWithFormat: @"%s", aux ];
    return str;
}

int main(int argc, const char * argv[]) {
    
    @autoreleasepool {
        NSMutableArray *electrodomesticos = [ [ NSMutableArray alloc ] init ];
        
        [ electrodomesticos addObject: [ [ Televisor alloc ] inicializarConResolucion: [ NSNumber numberWithInt: 35 ] ySintonizador: [ NSNumber numberWithBool: true ] ] ];
        [ electrodomesticos addObject: [ [ Electrodomestico alloc ] inicializarConPrecio: [ NSNumber numberWithInt: 564 ] Color: @"azul" Consumo: [ NSNumber numberWithChar: 'G' ] yPeso:[ NSNumber numberWithInt: 33 ] ] ];
        [ electrodomesticos addObject: [ [ Lavadora alloc ] inicializarConCarga: [ NSNumber numberWithInt: 45 ] ] ];
        [ electrodomesticos addObject: [ [ Electrodomestico alloc ] inicializar ] ];
        [ electrodomesticos addObject: [ [ Televisor alloc ] inicializar ] ];
        [ electrodomesticos addObject: [ [ Televisor alloc ] inicializarConPrecio: [ NSNumber numberWithInt: 1000 ] yPeso: [ NSNumber numberWithInt: 45 ] ] ];
        [ electrodomesticos addObject: [ [ Televisor alloc ] inicializarConResolucion: [ NSNumber numberWithInt: 12 ] ySintonizador: [ NSNumber numberWithBool: true ] ] ];
        [ electrodomesticos addObject: [ [ Lavadora alloc ] inicializarConPrecio: [ NSNumber numberWithInt: 430 ] yPeso: [ NSNumber numberWithInt: 50 ] ] ];
        [ electrodomesticos addObject: [ [ Electrodomestico alloc ] inicializarConPrecio: [ NSNumber numberWithInt: 1865 ] yPeso: [ NSNumber numberWithInt: 75 ] ] ];
        [ electrodomesticos addObject: [ [ Lavadora alloc ] inicializarConCarga: [ NSNumber numberWithInt: 45 ] ] ];
        
        int precioElectrodomesticos = 0, precioTelevisores = 0, precioLavadoras = 0;
        for( int i = 0; i < [ electrodomesticos count ]; i++ ) {
            Electrodomestico *actual = [ electrodomesticos objectAtIndex: 0 ];
            int precioActual =  [ actual precioFinal ];
            //[ actual imprimir ];
            //NSLog( @"El precio es: %d\n", precioActual );
            if( [ actual isKindOfClass: [ Electrodomestico class ] ] )
                precioElectrodomesticos += precioActual;
            if( [ actual class ] == [ Lavadora class ] )
                precioLavadoras += precioActual;
            if( [ actual class ] == [ Televisor class ] )
                precioTelevisores += precioActual;
        }
        NSLog( @"El valor de todos los electrodomesticos es: %d\n", precioElectrodomesticos );
        NSLog( @"El valor de todos los lavadoras es: %d\n", precioLavadoras );
        NSLog( @"El valor de todos los televisores es: %d\n", precioTelevisores );
    }
    return 0;
}