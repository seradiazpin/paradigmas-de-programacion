# import <Foundation/Foundation.h>
# include <stdlib.h>

@interface Person:NSObject{
	NSString * name;
	int age;
	int DNI;
	NSString * gender;
	double weight;
	double height; 
}

@property(nonatomic,readwrite,copy) NSString * name;
@property(nonatomic,readwrite) int age;
@property(nonatomic,readonly) int DNI;
@property(nonatomic,readwrite,copy) NSString * gender;
@property(nonatomic,readwrite) double weight;
@property(nonatomic,readwrite) double height;

-(id)init;
-(id)initWithName:(NSString *) name age:(int) age gender:(NSString *)gender;
-(id)initWithName:(NSString *) name age:(int) age gender:(NSString *)gender weight:(double)weight height:(double)height;  

-(int)computeCMI;
-(bool)isAdult;

-(NSString *)toString;

@end


@implementation Person

@synthesize name;
@synthesize age;
@synthesize DNI;
@synthesize gender;
@synthesize weight;
@synthesize height;

+(NSString *)validateGender:(NSString *)gender{
	if([gender isEqualToString:@"M" ] || [gender isEqualToString:@"H" ]){
		return gender;
	}
	return @"H";
}

+(int)generateDNI{
	return rand() % 90000000 + 10000000 ;
}
	
-(id)init{
	name = @"";
	age = 0;
	DNI = [Person generateDNI];
	gender = @"";
	weight = 0;
	height = 0;
	return self;
}

-(id)initWithName:(NSString *) _name age:(int) _age gender:(NSString *)_gender{
	name = _name;
	age = _age;
	DNI = [Person generateDNI];
	gender = [Person validateGender:_gender];
	weight = 0;
	height = 0;
	return self;
}

-(id)initWithName:(NSString *) _name age:(int) _age gender:(NSString *)_gender weight:(double)_weight height:(double)_height{
	name = _name;
	age = _age;
	DNI = [Person generateDNI];
	gender = [Person validateGender:_gender];
	weight = _weight;
	height = _height;
	return self;
}

-(int)computeCMI{
	double cmi = weight/(height*height);
	NSLog(@"%f",cmi);
	if(cmi >= 18.5f && cmi <=24.99f ) return 0;
	else if(cmi >=25.00f ) return 1;
	return -1;
}

-(NSString *)toString{
	return [NSString stringWithFormat:@"Name: %@, age %d, DNI %d, gender %@, weight %f height %f\n",name,age,DNI,gender,weight,height];
}

-(bool)isAdult{
	return age>=18;
}

@end

NSString * readString(){
	char aux[100];
	scanf("%s",aux);
	NSString *str = [NSString stringWithFormat:@"%s", aux];
	return str;
}

inline void initRandomGenerator(){
	srand(time(NULL));
}

int main(int argc, char const *argv[])
{	
	initRandomGenerator();

	NSAutoreleasePool *myPool = [[NSAutoreleasePool alloc] init];

	NSString * name, * gender;
	int age;
	double height,weight;

	NSLog(@"Ingrese un nombre\n");
	name = readString();

	NSLog(@"Ingrese la edad\n");
	scanf("%d",&age);

	NSLog(@"Ingrese el sexo\n");
	gender = readString();

	NSLog(@"Ingrese el peso\n");
	scanf("%lf",&weight);

	NSLog(@"Ingrese la altura\n");
	scanf("%lf",&height);

	Person * person1 = [ [Person alloc] initWithName:name age:age gender:gender weight:weight height:height ];
	Person * person2 = [ [Person alloc] initWithName: name age:age gender:gender]; 
	Person * person3 = [ [Person alloc] init];

	NSLog([person1 toString]);
	NSLog(@"Es mayor de edad? 1/0 %d",[person1 isAdult]);
	NSLog(@"Estado de forma -1/0/1: %d",[person1 computeCMI]);

	NSLog([person2 toString]);
	NSLog(@"Es mayor de edad? 1/0 %d",[person2 isAdult]);
	NSLog(@"Estado de forma -1/0/1: %d",[person2 computeCMI]);

	NSLog([person3 toString]);
	NSLog(@"Es mayor de edad? 1/0 %d",[person3 isAdult]);
	NSLog(@"Estado de forma -1/0/1: %d",[person3 computeCMI]);

	// Your code that uses autorelease...
	[myPool drain];

	return 0;
}

















